//
//  ProgressMeterXcode12App.swift
//  ProgressMeterXcode12
//
//  Created by Russell Gordon on 2020-08-16.
//

import SwiftUI

@main
struct ProgressMeterXcode12App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
